
from . import biometric_device_details
from . import zk_machine_attendance
from . import daily_attendance
from . import hr_employee
from . import hs_shifts
