## Module <hr_zk_attendance>

#### 16.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial commit for Biometric Device Integration
